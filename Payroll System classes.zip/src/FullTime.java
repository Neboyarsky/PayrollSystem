public class FullTime extends Employee{

}
