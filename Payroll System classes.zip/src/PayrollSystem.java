public class PayrollSystem {
    public static void main(String[] args) {

    }
}
