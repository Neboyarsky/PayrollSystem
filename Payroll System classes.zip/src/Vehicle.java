public class Vehicle {
}
