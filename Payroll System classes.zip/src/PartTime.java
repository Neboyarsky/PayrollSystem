public class PartTime extends Employee{

}
